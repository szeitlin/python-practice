#
# File:   designLab01Work.py
# Author: 6.01 Staff
# Date:   02-Sep-11
#
# Below are templates for your answers to three parts of Design Lab 1

#-----------------------------------------------------------------------------

def fib(n):
    # Delete the pass statement below and insert your own code
    pass

#-----------------------------------------------------------------------------

class V2:
    # Delete the pass statement below and insert your own code
    pass

#-----------------------------------------------------------------------------

class Polynomial:
    # Delete the pass statement below and insert your own code
    pass

